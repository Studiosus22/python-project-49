### Hexlet tests and linter status:
[![Actions Status](https://github.com/Studiosus22/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Studiosus22/python-project-49/actions)

<a href="https://codeclimate.com/github/Studiosus22/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/67f6c2c309719fb9cb9b/maintainability" /></a>

package install and "Is even?" game asciinema:  https://asciinema.org/a/HyO4ZsFhmQHetERp6hiFW0lwC

"Calculator" game asciinema: https://asciinema.org/a/9Ep8mVgupTu6LcwhpzycOEm5p

"Greatest common divisor" game asciinema: https://asciinema.org/a/IrRYxq445GrZxP7cJeip9sxSV

"Progression" game asciinema: https://asciinema.org/a/wecZ1JBl37sKa49NDB5qmxI8j

"Is prime?" game asciinema: https://asciinema.org/a/5v778ynJdjRHJ0I8pvzAAdCFL

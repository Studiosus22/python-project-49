# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': "'Brain games' - arithmetic games package",
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Studiosus22/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Studiosus22/python-project-49/actions)\n\n<a href="https://codeclimate.com/github/Studiosus22/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/67f6c2c309719fb9cb9b/maintainability" /></a>\n\npackage install and "Is even?" game asciinema:  https://asciinema.org/a/acPA5IXawYE8UNkOrGSBy7niX\n\n"Calculator" game asciinema: https://asciinema.org/a/4CQz3FJEKcRkM2X4aqdeahSDn\n\n"Greatest common divisor" game asciinema: https://asciinema.org/a/f3KuYTPC6ucMrFZw7iLO3eQJm\n\n"Progression" game asciinema: https://asciinema.org/a/gR0dgWswgrCdeMEqnRFs8lMsj\n\n"Is prime?" game asciinema: https://asciinema.org/a/JLbDQgKhSNjQuYrmUrRWDNwX2\n',
    'author': 'Mikhail Zyryanov',
    'author_email': 'mzyryanov@list.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/Studiosus22/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0',
}


setup(**setup_kwargs)

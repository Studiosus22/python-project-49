### Hexlet tests and linter status:
[![Actions Status](https://github.com/Studiosus22/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Studiosus22/python-project-49/actions)

<a href="https://codeclimate.com/github/Studiosus22/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/67f6c2c309719fb9cb9b/maintainability" /></a>

package install and "is even" game asciinema:  https://asciinema.org/a/acPA5IXawYE8UNkOrGSBy7niX


### Hexlet tests and linter status:
[![Actions Status](https://github.com/Studiosus22/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Studiosus22/python-project-49/actions)
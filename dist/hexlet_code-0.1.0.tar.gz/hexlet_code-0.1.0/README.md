### Hexlet tests and linter status:
[![Actions Status](https://github.com/Studiosus22/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Studiosus22/python-project-49/actions)

<a href="https://codeclimate.com/github/Studiosus22/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/67f6c2c309719fb9cb9b/maintainability" /></a>

package install and "Is even?" game asciinema:  https://asciinema.org/a/acPA5IXawYE8UNkOrGSBy7niX

"Calculator" game asciinema: https://asciinema.org/a/4CQz3FJEKcRkM2X4aqdeahSDn

"Greatest common divisor" game asciinema: https://asciinema.org/a/f3KuYTPC6ucMrFZw7iLO3eQJm

"Progression" game asciinema: https://asciinema.org/a/gR0dgWswgrCdeMEqnRFs8lMsj

"Is prime?" game asciinema: https://asciinema.org/a/JLbDQgKhSNjQuYrmUrRWDNwX2
